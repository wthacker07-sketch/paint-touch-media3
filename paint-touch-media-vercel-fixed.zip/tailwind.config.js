/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./data/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        ink: "#09090b",
        paper: "#fbfbf8",
        line: "#e7e7df",
        electric: "#1769ff",
        rim: "#ff5a1f",
        press: "#ef233c",
        volt: "#b7ff35"
      },
      boxShadow: {
        card: "0 18px 55px rgba(9, 9, 11, 0.09)",
        glow: "0 18px 70px rgba(23, 105, 255, 0.18)"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Arial Black", "Inter", "ui-sans-serif", "system-ui", "sans-serif"]
      }
    }
  },
  plugins: []
};
